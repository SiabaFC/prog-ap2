class CORES:
    preto = (0, 0, 0)
    branco = (255, 255, 255)
    vermelho = (255, 0, 0)
    verde = (0, 255, 0)
    azul = (0, 0, 255)
